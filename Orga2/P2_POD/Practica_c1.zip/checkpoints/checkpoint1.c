#include "checkpoints.h"

/** AUX FUNCTIONS **/

/* Funciones */

#define FLOAT_ARR_SIZE 10

/**
	Checkpoint 1: inicialización estática y dinámica
	Por favor completen la parte del código marcada con ? según lo indicado en el enunciado
*/

void checkpoint_1(){
	uint32_t i;	
	printf("[Checkpoint 1]:\n========\n");
	//Inicialice estáticamente un arreglo de floats de tamaño FLOAT_ARR_SIZE
	//COMPLETAR:
	float float_not_initialized_array[FLOAT_ARR_SIZE];       //inicializamos de forma estatica 
	//? float_not_initialized_array[?];


	printf("Inicialización estática:\n========\n");
	printf("\tArray de floats:\n");

	float float_static_array[FLOAT_ARR_SIZE];
	for(i = 0; i < FLOAT_ARR_SIZE; i++){
		//COMPLETAR:
		float_static_array[i]= i / 2.0f;
		printf("\t[%d]:\t%f\n", i, float_static_array[i]); // Que son los %? <-- %letra es que tipo de dato printea ( cambiamos las t a f)
	}   // | printeo matcheado con los tipos que definis, que se reemplazan con lo que viene siguiente en la tupla, por orden.
	


	//Inicialice dinámicamente un arreglo de floats de tamaño FLOAT_ARR_SIZE
	//COMPLETAR:

	float* float_dynamic_array = malloc(sizeof(float) * FLOAT_ARR_SIZE);       //inicializamos de forma dinamica <---el malloc es un new de c++ primitivo.
	// == float *float_dynamic_array = malloc(sizeof(float) * FLOAT_ARR_SIZE);

	//? ?float_dynamic_array	= ?;

	//Imprima los valores del arreglo por la salida estándar
	printf("Inicialización dinámica:\n========\n");
	printf("\tArray de floats:\n");
	for(i = 0; i < FLOAT_ARR_SIZE; i++){
		float_dynamic_array[i]	= i / 2.0f;
		//COMPLETAR:	
		printf("\t[%d]:\t%f\n", i, float_dynamic_array[i]);
	}

		
	//Libere la región de memoria reservada para el arreglo dinámico
	//COMPLETAR:
	free(float_dynamic_array);           //free en el heap <- No hacemos el free del estatico pq esta en stack.
	//?(float_dynamic_array);
}

/*

-> Diferencias entre ambas inicializaciones:       <- Stack: temporales ; Heap: dinamicos ; Data: estaticos 

Dinamico: Va al heap el arreglo. Despues hay que hacer el free()

Estatico: Si inicializamos un array estatico en una funcion va al stack. Se pierde despues de terminar de ejecutar la funcion.

Siempre que definamos algo dentro de una funcion va al stack.
El heap SOLO se manipula con malloc y free.

*/